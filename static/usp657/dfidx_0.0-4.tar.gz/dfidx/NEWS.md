# dfidx 0.0-1

* initial version of dfidx posted on github

